-- Docs: https://docs.mage.ai/guides/sql-blocks
SELECT DISTINCT vendor_id FROM mage.green_taxi;